# typist

I wrote a keyboard typing program to get used to my new NIU 40% ortholinear
keyboard. Also, I wanted to learn some `Go` during COVID-19.

![screenshot](https://github.com/noqqe/typist/raw/master/screenshot.png)

# Install

    go build .
    ./typist

# Todos

[] persist stats to file

